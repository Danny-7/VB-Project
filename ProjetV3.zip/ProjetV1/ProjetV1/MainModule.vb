﻿Module MainModule

    Private accueil As FormAccueil
    Private candidat As FormCandid
    Private epreuve As FormEpv
    Private recap As FormRecap
    Private modifSuppr As FormModifSuppr
    Private inscrits As List(Of Candidat) = New List(Of Candidat)

    Sub Main()
        accueil = New FormAccueil
        candidat = New FormCandid
        epreuve = New FormEpv
        recap = New FormRecap
        modifSuppr = New FormModifSuppr
        Application.Run(accueil)
    End Sub

    Public Sub ShowCandidat()
        candidat.Visible = True
    End Sub

    Public Sub ShowAccueil()
        accueil.Visible = True
    End Sub

    Public Sub ShowEpreuve()
        epreuve.Visible = True
    End Sub

    Public Sub ShowRecap()
        recap.Visible = True
    End Sub

    Public Sub ShowModifSuppr()
        modifSuppr.Visible = True
    End Sub

    Public Function GetNom() As String
        Return candidat.TbNom.Text
    End Function

    Public Function GetPrenom() As String
        Return candidat.TbPrenom.Text
    End Function

    Public Sub AjouterCandidat(ByRef candidat As Candidat)
        inscrits.Add(candidat)
    End Sub

    Public Function créerCandidat() As Candidat
        Return candidat.créerCandidat()
    End Function

    Public Function GetNbInscits() As Integer
        Return inscrits.Count
    End Function

    Public Sub AjouterEpreuves(ByRef c As Candidat)
        epreuve.AjouterEpreuves(c)
    End Sub

    Public Function GetListeOfCandidats() As List(Of Candidat)
        Return inscrits
    End Function

    Public Sub ClearForms()
        candidat.ClearForm()
        epreuve.ClearForm()
    End Sub
End Module
