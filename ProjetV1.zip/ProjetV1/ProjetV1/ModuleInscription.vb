﻿Module ModuleInscription
    Public Structure Candidat
        Dim nom As String
        Dim prenom As Stri
    End Structure
End Module
