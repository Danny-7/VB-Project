﻿Module MainModule

    Private accueil As FormAccueil
    Private candidat As FormCandid
    Private epreuve As FormEpv
    Private recap As FormRecap
    Private modifSuppr As FormModifSuppr
    Private etatInsc As FormEtatInsc
    Private bilan As FormBilan
    Private inscrits As List(Of Candidat) = New List(Of Candidat)

    Public écritDictionnaire As New Dictionary(Of String, String)

    Public oralDictionnaire As New Dictionary(Of String, String)

    Private Sub MakeDictionary()
        écritDictionnaire.Add("Algorithme", "ALG")
        écritDictionnaire.Add("Base de données", "BDD")
        écritDictionnaire.Add("Droit", "DRO")
        écritDictionnaire.Add("Expression", "EXP")
        écritDictionnaire.Add("Gestion", "GES")
        écritDictionnaire.Add("Langage C", "LAC")
        écritDictionnaire.Add("Langage Java", "LAJ")
        écritDictionnaire.Add("Mathématiques", "MAT")
        écritDictionnaire.Add("Programmation web", "PRW")
        écritDictionnaire.Add("Réseau", "RES")
        écritDictionnaire.Add("Système", "SYS")
        écritDictionnaire.Add("Visual Basic .NET", "VBN")

        oralDictionnaire.Add("Droit", "DRO")
        oralDictionnaire.Add("Expression", "EXP")
        oralDictionnaire.Add("Gestion", "GES")
        oralDictionnaire.Add("Mathématiques", "MAT")
        oralDictionnaire.Add("Réseau", "RES")
        oralDictionnaire.Add("Système", "SYS")
        oralDictionnaire.Add("Anglais", "ANG")
        oralDictionnaire.Add("Chinois", "CHI")
        oralDictionnaire.Add("Espagnol", "ESP")
    End Sub

    Sub Main()
        accueil = New FormAccueil
        candidat = New FormCandid
        epreuve = New FormEpv
        recap = New FormRecap
        modifSuppr = New FormModifSuppr
        etatInsc = New FormEtatInsc
        bilan = New FormBilan
        MakeDictionary()
        Application.Run(accueil)
    End Sub

    Public Sub ShowCandidat()
        candidat.Visible = True
    End Sub

    Public Sub ShowAccueil()
        accueil.Visible = True
    End Sub

    Public Sub ShowEpreuve()
        epreuve.Visible = True
    End Sub

    Public Sub ShowRecap()
        recap.Visible = True
    End Sub

    Public Sub ShowModifSuppr()
        modifSuppr.Visible = True
    End Sub

    Public Sub ShowEtatInsc()
        etatInsc.Visible = True
    End Sub

    Public Sub ShowBilan()
        bilan.Visible = True
    End Sub

    Public Function GetNom() As String
        Return candidat.TbNom.Text
    End Function

    Public Function GetPrenom() As String
        Return candidat.TbPrenom.Text
    End Function

    Public Sub AjouterCandidat(ByRef candidat As Candidat)
        inscrits.Add(candidat)
    End Sub

    Public Function CréerCandidat() As Candidat
        Return candidat.CréerCandidat()
    End Function

    Public Function CréerCandidat(ByVal id As Integer) As Candidat
        Return candidat.CréerCandidat(id)
    End Function

    ' change le candidat à afficher dans le formulaire récap
    Public Sub SetCandidat(ByRef c As Candidat)
        recap.SetCandidat(c)
    End Sub

    Public Function GetNbInscits() As Integer
        Return inscrits.Count
    End Function

    Public Function GetListeOfCandidats() As List(Of Candidat)
        Return inscrits
    End Function

    ' retourne un candidat en fonction de son identifiant
    Public Function GetCandidat(ByVal id As Integer) As Candidat
        For Each i In inscrits
            If i.GetCandidat.GetId = id Then
                Return i
            End If
        Next
        Return Nothing
    End Function

    ' supprime un candidat à partir de son identifiant
    Public Sub DeleteCandidat(ByVal id As Integer)
        Dim c As Candidat = GetCandidat(id)
        If c IsNot Nothing Then
            inscrits.Remove(c)
        End If

    End Sub

    Public Sub ClearForms()
        candidat.ClearForm()
        epreuve.ClearForm()
    End Sub

    Public Sub modeInscription()
        recap.modeInscription()
    End Sub

    Public Sub modeSuppr()
        recap.modeSuppr()
    End Sub

    Public Sub LoadCandidat(ByRef c As Candidat)
        candidat.LoadCandidat(c)
    End Sub

    Public Sub LoadEpreuves(ByRef c As Candidat)
        epreuve.LoadEpreuves(c)
    End Sub
End Module
