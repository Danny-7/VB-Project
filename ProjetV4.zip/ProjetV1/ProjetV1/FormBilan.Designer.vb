﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormBilan
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelNbCandi = New System.Windows.Forms.Label()
        Me.BtnCandidat = New System.Windows.Forms.Button()
        Me.BtnMatiere = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.LabelCandidat = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(152, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(172, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nombre de candidatures :"
        '
        'LabelNbCandi
        '
        Me.LabelNbCandi.AutoSize = True
        Me.LabelNbCandi.Location = New System.Drawing.Point(330, 20)
        Me.LabelNbCandi.Name = "LabelNbCandi"
        Me.LabelNbCandi.Size = New System.Drawing.Size(51, 17)
        Me.LabelNbCandi.TabIndex = 1
        Me.LabelNbCandi.Text = "Label2"
        '
        'BtnCandidat
        '
        Me.BtnCandidat.Location = New System.Drawing.Point(63, 169)
        Me.BtnCandidat.Name = "BtnCandidat"
        Me.BtnCandidat.Size = New System.Drawing.Size(163, 74)
        Me.BtnCandidat.TabIndex = 2
        Me.BtnCandidat.Text = "Afficher le bilan de candidature"
        Me.BtnCandidat.UseVisualStyleBackColor = True
        '
        'BtnMatiere
        '
        Me.BtnMatiere.Location = New System.Drawing.Point(312, 169)
        Me.BtnMatiere.Name = "BtnMatiere"
        Me.BtnMatiere.Size = New System.Drawing.Size(163, 74)
        Me.BtnMatiere.TabIndex = 3
        Me.BtnMatiere.Text = "Afficher le bilan de la matière"
        Me.BtnMatiere.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(63, 107)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(163, 24)
        Me.ComboBox1.TabIndex = 4
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(312, 107)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(162, 24)
        Me.ComboBox2.TabIndex = 5
        '
        'LabelCandidat
        '
        Me.LabelCandidat.AutoSize = True
        Me.LabelCandidat.Location = New System.Drawing.Point(60, 77)
        Me.LabelCandidat.Name = "LabelCandidat"
        Me.LabelCandidat.Size = New System.Drawing.Size(71, 17)
        Me.LabelCandidat.TabIndex = 6
        Me.LabelCandidat.Text = "Candidats"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(309, 77)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 17)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Matières"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(257, 198)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(29, 17)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "OU"
        '
        'FormBilan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(550, 319)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.LabelCandidat)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.BtnMatiere)
        Me.Controls.Add(Me.BtnCandidat)
        Me.Controls.Add(Me.LabelNbCandi)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormBilan"
        Me.Text = "FormBilan"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents LabelNbCandi As Label
    Friend WithEvents BtnCandidat As Button
    Friend WithEvents BtnMatiere As Button
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents LabelCandidat As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
End Class
