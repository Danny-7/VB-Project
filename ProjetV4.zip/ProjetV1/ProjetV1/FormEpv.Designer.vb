﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormEpv
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelNom = New System.Windows.Forms.Label()
        Me.LabelPrenom = New System.Windows.Forms.Label()
        Me.CbRegion = New System.Windows.Forms.ComboBox()
        Me.LabelRegion = New System.Windows.Forms.Label()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox5 = New System.Windows.Forms.CheckBox()
        Me.CheckBox12 = New System.Windows.Forms.CheckBox()
        Me.CheckBox11 = New System.Windows.Forms.CheckBox()
        Me.CheckBox10 = New System.Windows.Forms.CheckBox()
        Me.CheckBox9 = New System.Windows.Forms.CheckBox()
        Me.CheckBox8 = New System.Windows.Forms.CheckBox()
        Me.CheckBox7 = New System.Windows.Forms.CheckBox()
        Me.CheckBox21 = New System.Windows.Forms.CheckBox()
        Me.CheckBox20 = New System.Windows.Forms.CheckBox()
        Me.CheckBox19 = New System.Windows.Forms.CheckBox()
        Me.CheckBox18 = New System.Windows.Forms.CheckBox()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.CheckBox16 = New System.Windows.Forms.CheckBox()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.CheckBox14 = New System.Windows.Forms.CheckBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.LabelEcrit = New System.Windows.Forms.Label()
        Me.LabelOral = New System.Windows.Forms.Label()
        Me.LabelCptEcrit = New System.Windows.Forms.Label()
        Me.LabelCptOral = New System.Windows.Forms.Label()
        Me.PanelEcrit = New System.Windows.Forms.Panel()
        Me.PanelOral = New System.Windows.Forms.Panel()
        Me.TbCptEcrit = New System.Windows.Forms.TextBox()
        Me.TbCptOral = New System.Windows.Forms.TextBox()
        Me.PanelFacultatif = New System.Windows.Forms.Panel()
        Me.RbNon = New System.Windows.Forms.RadioButton()
        Me.RbOui = New System.Windows.Forms.RadioButton()
        Me.LabelFacultatif = New System.Windows.Forms.Label()
        Me.CbFacultatif = New System.Windows.Forms.ComboBox()
        Me.LabelMatRest = New System.Windows.Forms.Label()
        Me.BtnAbandon = New System.Windows.Forms.Button()
        Me.BtnValider = New System.Windows.Forms.Button()
        Me.LabelID = New System.Windows.Forms.Label()
        Me.PanelEcrit.SuspendLayout()
        Me.PanelOral.SuspendLayout()
        Me.PanelFacultatif.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelNom
        '
        Me.LabelNom.AutoSize = True
        Me.LabelNom.Location = New System.Drawing.Point(66, 19)
        Me.LabelNom.Name = "LabelNom"
        Me.LabelNom.Size = New System.Drawing.Size(51, 17)
        Me.LabelNom.TabIndex = 0
        Me.LabelNom.Text = "Label1"
        '
        'LabelPrenom
        '
        Me.LabelPrenom.AutoSize = True
        Me.LabelPrenom.Location = New System.Drawing.Point(192, 19)
        Me.LabelPrenom.Name = "LabelPrenom"
        Me.LabelPrenom.Size = New System.Drawing.Size(51, 17)
        Me.LabelPrenom.TabIndex = 1
        Me.LabelPrenom.Text = "Label2"
        '
        'CbRegion
        '
        Me.CbRegion.FormattingEnabled = True
        Me.CbRegion.Location = New System.Drawing.Point(454, 19)
        Me.CbRegion.Name = "CbRegion"
        Me.CbRegion.Size = New System.Drawing.Size(185, 24)
        Me.CbRegion.TabIndex = 2
        '
        'LabelRegion
        '
        Me.LabelRegion.AutoSize = True
        Me.LabelRegion.Location = New System.Drawing.Point(375, 22)
        Me.LabelRegion.Name = "LabelRegion"
        Me.LabelRegion.Size = New System.Drawing.Size(53, 17)
        Me.LabelRegion.TabIndex = 3
        Me.LabelRegion.Text = "Région"
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Location = New System.Drawing.Point(7, 6)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox1.TabIndex = 4
        Me.CheckBox1.Text = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Location = New System.Drawing.Point(7, 34)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox2.TabIndex = 5
        Me.CheckBox2.Text = "CheckBox2"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Location = New System.Drawing.Point(7, 89)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox4.TabIndex = 7
        Me.CheckBox4.Text = "CheckBox4"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Location = New System.Drawing.Point(7, 61)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox3.TabIndex = 6
        Me.CheckBox3.Text = "CheckBox3"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Location = New System.Drawing.Point(7, 142)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox6.TabIndex = 9
        Me.CheckBox6.Text = "CheckBox6"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox5
        '
        Me.CheckBox5.AutoSize = True
        Me.CheckBox5.Location = New System.Drawing.Point(7, 114)
        Me.CheckBox5.Name = "CheckBox5"
        Me.CheckBox5.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox5.TabIndex = 8
        Me.CheckBox5.Text = "CheckBox5"
        Me.CheckBox5.UseVisualStyleBackColor = True
        '
        'CheckBox12
        '
        Me.CheckBox12.AutoSize = True
        Me.CheckBox12.Location = New System.Drawing.Point(7, 305)
        Me.CheckBox12.Name = "CheckBox12"
        Me.CheckBox12.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox12.TabIndex = 15
        Me.CheckBox12.Text = "CheckBox12"
        Me.CheckBox12.UseVisualStyleBackColor = True
        '
        'CheckBox11
        '
        Me.CheckBox11.AutoSize = True
        Me.CheckBox11.Location = New System.Drawing.Point(7, 277)
        Me.CheckBox11.Name = "CheckBox11"
        Me.CheckBox11.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox11.TabIndex = 14
        Me.CheckBox11.Text = "CheckBox11"
        Me.CheckBox11.UseVisualStyleBackColor = True
        '
        'CheckBox10
        '
        Me.CheckBox10.AutoSize = True
        Me.CheckBox10.Location = New System.Drawing.Point(7, 252)
        Me.CheckBox10.Name = "CheckBox10"
        Me.CheckBox10.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox10.TabIndex = 13
        Me.CheckBox10.Text = "CheckBox10"
        Me.CheckBox10.UseVisualStyleBackColor = True
        '
        'CheckBox9
        '
        Me.CheckBox9.AutoSize = True
        Me.CheckBox9.Location = New System.Drawing.Point(7, 224)
        Me.CheckBox9.Name = "CheckBox9"
        Me.CheckBox9.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox9.TabIndex = 12
        Me.CheckBox9.Text = "CheckBox9"
        Me.CheckBox9.UseVisualStyleBackColor = True
        '
        'CheckBox8
        '
        Me.CheckBox8.AutoSize = True
        Me.CheckBox8.Location = New System.Drawing.Point(7, 197)
        Me.CheckBox8.Name = "CheckBox8"
        Me.CheckBox8.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox8.TabIndex = 11
        Me.CheckBox8.Text = "CheckBox8"
        Me.CheckBox8.UseVisualStyleBackColor = True
        '
        'CheckBox7
        '
        Me.CheckBox7.AutoSize = True
        Me.CheckBox7.Location = New System.Drawing.Point(7, 169)
        Me.CheckBox7.Name = "CheckBox7"
        Me.CheckBox7.Size = New System.Drawing.Size(100, 21)
        Me.CheckBox7.TabIndex = 10
        Me.CheckBox7.Text = "CheckBox7"
        Me.CheckBox7.UseVisualStyleBackColor = True
        '
        'CheckBox21
        '
        Me.CheckBox21.AutoSize = True
        Me.CheckBox21.Location = New System.Drawing.Point(8, 224)
        Me.CheckBox21.Name = "CheckBox21"
        Me.CheckBox21.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox21.TabIndex = 24
        Me.CheckBox21.Text = "CheckBox21"
        Me.CheckBox21.UseVisualStyleBackColor = True
        '
        'CheckBox20
        '
        Me.CheckBox20.AutoSize = True
        Me.CheckBox20.Location = New System.Drawing.Point(8, 197)
        Me.CheckBox20.Name = "CheckBox20"
        Me.CheckBox20.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox20.TabIndex = 23
        Me.CheckBox20.Text = "CheckBox20"
        Me.CheckBox20.UseVisualStyleBackColor = True
        '
        'CheckBox19
        '
        Me.CheckBox19.AutoSize = True
        Me.CheckBox19.Location = New System.Drawing.Point(8, 169)
        Me.CheckBox19.Name = "CheckBox19"
        Me.CheckBox19.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox19.TabIndex = 22
        Me.CheckBox19.Text = "CheckBox19"
        Me.CheckBox19.UseVisualStyleBackColor = True
        '
        'CheckBox18
        '
        Me.CheckBox18.AutoSize = True
        Me.CheckBox18.Location = New System.Drawing.Point(8, 142)
        Me.CheckBox18.Name = "CheckBox18"
        Me.CheckBox18.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox18.TabIndex = 21
        Me.CheckBox18.Text = "CheckBox18"
        Me.CheckBox18.UseVisualStyleBackColor = True
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Location = New System.Drawing.Point(8, 114)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox17.TabIndex = 20
        Me.CheckBox17.Text = "CheckBox17"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'CheckBox16
        '
        Me.CheckBox16.AutoSize = True
        Me.CheckBox16.Location = New System.Drawing.Point(8, 89)
        Me.CheckBox16.Name = "CheckBox16"
        Me.CheckBox16.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox16.TabIndex = 19
        Me.CheckBox16.Text = "CheckBox16"
        Me.CheckBox16.UseVisualStyleBackColor = True
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Location = New System.Drawing.Point(8, 61)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox15.TabIndex = 18
        Me.CheckBox15.Text = "CheckBox15"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'CheckBox14
        '
        Me.CheckBox14.AutoSize = True
        Me.CheckBox14.Location = New System.Drawing.Point(8, 34)
        Me.CheckBox14.Name = "CheckBox14"
        Me.CheckBox14.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox14.TabIndex = 17
        Me.CheckBox14.Text = "CheckBox14"
        Me.CheckBox14.UseVisualStyleBackColor = True
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Location = New System.Drawing.Point(8, 6)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(108, 21)
        Me.CheckBox13.TabIndex = 16
        Me.CheckBox13.Text = "CheckBox13"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'LabelEcrit
        '
        Me.LabelEcrit.AutoSize = True
        Me.LabelEcrit.Location = New System.Drawing.Point(66, 55)
        Me.LabelEcrit.Name = "LabelEcrit"
        Me.LabelEcrit.Size = New System.Drawing.Size(122, 17)
        Me.LabelEcrit.TabIndex = 25
        Me.LabelEcrit.Text = "Epreuves écrites :"
        '
        'LabelOral
        '
        Me.LabelOral.AutoSize = True
        Me.LabelOral.Location = New System.Drawing.Point(260, 55)
        Me.LabelOral.Name = "LabelOral"
        Me.LabelOral.Size = New System.Drawing.Size(119, 17)
        Me.LabelOral.TabIndex = 26
        Me.LabelOral.Text = "Epreuves orales :"
        '
        'LabelCptEcrit
        '
        Me.LabelCptEcrit.AutoSize = True
        Me.LabelCptEcrit.Location = New System.Drawing.Point(66, 440)
        Me.LabelCptEcrit.Name = "LabelCptEcrit"
        Me.LabelCptEcrit.Size = New System.Drawing.Size(105, 17)
        Me.LabelCptEcrit.TabIndex = 27
        Me.LabelCptEcrit.Text = "Choix restants :"
        '
        'LabelCptOral
        '
        Me.LabelCptOral.AutoSize = True
        Me.LabelCptOral.Location = New System.Drawing.Point(260, 356)
        Me.LabelCptOral.Name = "LabelCptOral"
        Me.LabelCptOral.Size = New System.Drawing.Size(105, 17)
        Me.LabelCptOral.TabIndex = 28
        Me.LabelCptOral.Text = "Choix restants :"
        '
        'PanelEcrit
        '
        Me.PanelEcrit.Controls.Add(Me.CheckBox12)
        Me.PanelEcrit.Controls.Add(Me.CheckBox11)
        Me.PanelEcrit.Controls.Add(Me.CheckBox10)
        Me.PanelEcrit.Controls.Add(Me.CheckBox9)
        Me.PanelEcrit.Controls.Add(Me.CheckBox8)
        Me.PanelEcrit.Controls.Add(Me.CheckBox7)
        Me.PanelEcrit.Controls.Add(Me.CheckBox6)
        Me.PanelEcrit.Controls.Add(Me.CheckBox5)
        Me.PanelEcrit.Controls.Add(Me.CheckBox4)
        Me.PanelEcrit.Controls.Add(Me.CheckBox3)
        Me.PanelEcrit.Controls.Add(Me.CheckBox2)
        Me.PanelEcrit.Controls.Add(Me.CheckBox1)
        Me.PanelEcrit.Location = New System.Drawing.Point(65, 89)
        Me.PanelEcrit.Name = "PanelEcrit"
        Me.PanelEcrit.Size = New System.Drawing.Size(168, 333)
        Me.PanelEcrit.TabIndex = 29
        '
        'PanelOral
        '
        Me.PanelOral.Controls.Add(Me.CheckBox21)
        Me.PanelOral.Controls.Add(Me.CheckBox20)
        Me.PanelOral.Controls.Add(Me.CheckBox19)
        Me.PanelOral.Controls.Add(Me.CheckBox18)
        Me.PanelOral.Controls.Add(Me.CheckBox17)
        Me.PanelOral.Controls.Add(Me.CheckBox16)
        Me.PanelOral.Controls.Add(Me.CheckBox15)
        Me.PanelOral.Controls.Add(Me.CheckBox14)
        Me.PanelOral.Controls.Add(Me.CheckBox13)
        Me.PanelOral.Location = New System.Drawing.Point(263, 89)
        Me.PanelOral.Name = "PanelOral"
        Me.PanelOral.Size = New System.Drawing.Size(164, 253)
        Me.PanelOral.TabIndex = 30
        '
        'TbCptEcrit
        '
        Me.TbCptEcrit.Enabled = False
        Me.TbCptEcrit.Location = New System.Drawing.Point(177, 440)
        Me.TbCptEcrit.Name = "TbCptEcrit"
        Me.TbCptEcrit.Size = New System.Drawing.Size(56, 22)
        Me.TbCptEcrit.TabIndex = 31
        '
        'TbCptOral
        '
        Me.TbCptOral.Enabled = False
        Me.TbCptOral.Location = New System.Drawing.Point(371, 356)
        Me.TbCptOral.Name = "TbCptOral"
        Me.TbCptOral.Size = New System.Drawing.Size(56, 22)
        Me.TbCptOral.TabIndex = 32
        '
        'PanelFacultatif
        '
        Me.PanelFacultatif.Controls.Add(Me.RbNon)
        Me.PanelFacultatif.Controls.Add(Me.RbOui)
        Me.PanelFacultatif.Enabled = False
        Me.PanelFacultatif.Location = New System.Drawing.Point(459, 89)
        Me.PanelFacultatif.Name = "PanelFacultatif"
        Me.PanelFacultatif.Size = New System.Drawing.Size(83, 69)
        Me.PanelFacultatif.TabIndex = 33
        '
        'RbNon
        '
        Me.RbNon.AutoSize = True
        Me.RbNon.Location = New System.Drawing.Point(14, 44)
        Me.RbNon.Name = "RbNon"
        Me.RbNon.Size = New System.Drawing.Size(55, 21)
        Me.RbNon.TabIndex = 1
        Me.RbNon.TabStop = True
        Me.RbNon.Text = "Non"
        Me.RbNon.UseVisualStyleBackColor = True
        '
        'RbOui
        '
        Me.RbOui.AutoSize = True
        Me.RbOui.Location = New System.Drawing.Point(14, 6)
        Me.RbOui.Name = "RbOui"
        Me.RbOui.Size = New System.Drawing.Size(51, 21)
        Me.RbOui.TabIndex = 0
        Me.RbOui.TabStop = True
        Me.RbOui.Text = "Oui"
        Me.RbOui.UseVisualStyleBackColor = True
        '
        'LabelFacultatif
        '
        Me.LabelFacultatif.AutoSize = True
        Me.LabelFacultatif.Location = New System.Drawing.Point(456, 55)
        Me.LabelFacultatif.Name = "LabelFacultatif"
        Me.LabelFacultatif.Size = New System.Drawing.Size(137, 17)
        Me.LabelFacultatif.TabIndex = 34
        Me.LabelFacultatif.Text = "Epreuve facultative :"
        '
        'CbFacultatif
        '
        Me.CbFacultatif.FormattingEnabled = True
        Me.CbFacultatif.Location = New System.Drawing.Point(457, 205)
        Me.CbFacultatif.Name = "CbFacultatif"
        Me.CbFacultatif.Size = New System.Drawing.Size(182, 24)
        Me.CbFacultatif.TabIndex = 35
        Me.CbFacultatif.Visible = False
        '
        'LabelMatRest
        '
        Me.LabelMatRest.AutoSize = True
        Me.LabelMatRest.Location = New System.Drawing.Point(457, 182)
        Me.LabelMatRest.Name = "LabelMatRest"
        Me.LabelMatRest.Size = New System.Drawing.Size(125, 17)
        Me.LabelMatRest.TabIndex = 36
        Me.LabelMatRest.Text = "Matières restantes"
        Me.LabelMatRest.Visible = False
        '
        'BtnAbandon
        '
        Me.BtnAbandon.Location = New System.Drawing.Point(105, 487)
        Me.BtnAbandon.Name = "BtnAbandon"
        Me.BtnAbandon.Size = New System.Drawing.Size(138, 49)
        Me.BtnAbandon.TabIndex = 37
        Me.BtnAbandon.Text = "Abandonner"
        Me.BtnAbandon.UseVisualStyleBackColor = True
        '
        'BtnValider
        '
        Me.BtnValider.Location = New System.Drawing.Point(327, 487)
        Me.BtnValider.Name = "BtnValider"
        Me.BtnValider.Size = New System.Drawing.Size(138, 49)
        Me.BtnValider.TabIndex = 38
        Me.BtnValider.Text = "Valider"
        Me.BtnValider.UseVisualStyleBackColor = True
        '
        'LabelID
        '
        Me.LabelID.AutoSize = True
        Me.LabelID.Location = New System.Drawing.Point(610, 519)
        Me.LabelID.Name = "LabelID"
        Me.LabelID.Size = New System.Drawing.Size(16, 17)
        Me.LabelID.TabIndex = 39
        Me.LabelID.Text = "0"
        Me.LabelID.Visible = False
        '
        'FormEpv
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(652, 590)
        Me.Controls.Add(Me.LabelID)
        Me.Controls.Add(Me.BtnValider)
        Me.Controls.Add(Me.BtnAbandon)
        Me.Controls.Add(Me.LabelMatRest)
        Me.Controls.Add(Me.CbFacultatif)
        Me.Controls.Add(Me.LabelFacultatif)
        Me.Controls.Add(Me.PanelFacultatif)
        Me.Controls.Add(Me.TbCptOral)
        Me.Controls.Add(Me.TbCptEcrit)
        Me.Controls.Add(Me.PanelOral)
        Me.Controls.Add(Me.PanelEcrit)
        Me.Controls.Add(Me.LabelCptOral)
        Me.Controls.Add(Me.LabelCptEcrit)
        Me.Controls.Add(Me.LabelOral)
        Me.Controls.Add(Me.LabelEcrit)
        Me.Controls.Add(Me.LabelRegion)
        Me.Controls.Add(Me.CbRegion)
        Me.Controls.Add(Me.LabelPrenom)
        Me.Controls.Add(Me.LabelNom)
        Me.Name = "FormEpv"
        Me.Text = "Choix des épreuves"
        Me.PanelEcrit.ResumeLayout(False)
        Me.PanelEcrit.PerformLayout()
        Me.PanelOral.ResumeLayout(False)
        Me.PanelOral.PerformLayout()
        Me.PanelFacultatif.ResumeLayout(False)
        Me.PanelFacultatif.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LabelNom As Label
    Friend WithEvents LabelPrenom As Label
    Friend WithEvents CbRegion As ComboBox
    Friend WithEvents LabelRegion As Label
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox4 As CheckBox
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents CheckBox6 As CheckBox
    Friend WithEvents CheckBox5 As CheckBox
    Friend WithEvents CheckBox12 As CheckBox
    Friend WithEvents CheckBox11 As CheckBox
    Friend WithEvents CheckBox10 As CheckBox
    Friend WithEvents CheckBox9 As CheckBox
    Friend WithEvents CheckBox8 As CheckBox
    Friend WithEvents CheckBox7 As CheckBox
    Friend WithEvents CheckBox21 As CheckBox
    Friend WithEvents CheckBox20 As CheckBox
    Friend WithEvents CheckBox19 As CheckBox
    Friend WithEvents CheckBox18 As CheckBox
    Friend WithEvents CheckBox17 As CheckBox
    Friend WithEvents CheckBox16 As CheckBox
    Friend WithEvents CheckBox15 As CheckBox
    Friend WithEvents CheckBox14 As CheckBox
    Friend WithEvents CheckBox13 As CheckBox
    Friend WithEvents LabelEcrit As Label
    Friend WithEvents LabelOral As Label
    Friend WithEvents LabelCptEcrit As Label
    Friend WithEvents LabelCptOral As Label
    Friend WithEvents PanelEcrit As Panel
    Friend WithEvents PanelOral As Panel
    Friend WithEvents TbCptEcrit As TextBox
    Friend WithEvents TbCptOral As TextBox
    Friend WithEvents PanelFacultatif As Panel
    Friend WithEvents RbNon As RadioButton
    Friend WithEvents RbOui As RadioButton
    Friend WithEvents LabelFacultatif As Label
    Friend WithEvents CbFacultatif As ComboBox
    Friend WithEvents LabelMatRest As Label
    Friend WithEvents BtnAbandon As Button
    Friend WithEvents BtnValider As Button
    Friend WithEvents LabelID As Label
End Class
