﻿Module MainModule

    Private accueil As FormAccueil
    Private candidat As FormCandid
    Private epreuve As FormEpv
    Private inscrits As List(Of Candidat) = New List(Of Candidat)

    Sub Main()
        accueil = New FormAccueil
        candidat = New FormCandid
        epreuve = New FormEpv

        Application.Run(accueil)

    End Sub

    Public Sub ShowCandidat()
        candidat.Visible = True
    End Sub

    Public Sub ShowAccueil()
        accueil.Visible = True
    End Sub

    Public Sub ShowEpreuve()
        epreuve.Visible = True
    End Sub

    Public Function GetNom() As String
        Return candidat.TbNom.Text
    End Function

    Public Function GetPrenom() As String
        Return candidat.TbPrenom.Text
    End Function

    Public Sub AjouterCandidat(ByRef candidat As Candidat)
        inscrits.Add(candidat)
    End Sub

    Public Function GetNbInscits() As Integer
        Return inscrits.Count
    End Function

End Module
