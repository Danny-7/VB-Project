﻿Public Class Candidat

    Private id As Integer
    Private nom As String
    Private prenom As String
    Private adresse As String
    Private codePostal As String
    Private ville As String
    Private age As Integer
    Private epreuves As List(Of Epreuve)

    Private Shared cpt As Integer = 0

    Public Enum Type
        Ecrite
        Oral
        Facultatif
    End Enum

    Public Sub New(nom, prenom, adresse, cp, ville, age, epreuves)
        id = cpt
        cpt += 1
        Me.nom = nom
        Me.prenom = prenom
        Me.adresse = adresse
        Me.codePostal = cp
        Me.ville = ville
        Me.age = age
        Me.epreuves = epreuves
    End Sub

    Public Structure Epreuve
        Dim nom As String
        Dim type As String
    End Structure

    Public Function GetId() As Integer
        Return Me.id
    End Function



End Class
