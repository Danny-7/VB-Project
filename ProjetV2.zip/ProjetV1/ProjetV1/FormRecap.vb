﻿Public Class FormRecap
    Private Sub FormRecap_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub BtnAbandon_Click(sender As Object, e As EventArgs) Handles BtnAbandon.Click
        MainModule.ShowAccueil()
        Me.Visible = False
    End Sub
End Class